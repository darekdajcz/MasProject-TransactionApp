package TransactionModels;

public enum TransferType {
    LOCAL, INTERNATIONAL
}
