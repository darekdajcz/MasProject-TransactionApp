package TransactionModels;

public enum PayoutType {
    CASH, CARD
}
