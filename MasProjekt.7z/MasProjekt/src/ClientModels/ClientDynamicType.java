package ClientModels;

public enum ClientDynamicType {
    UNREGISTERED_CLIENT, REGISTERED_CLIENT
}
