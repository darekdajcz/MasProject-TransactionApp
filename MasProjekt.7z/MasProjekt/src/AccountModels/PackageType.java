package AccountModels;

public enum PackageType {
    CLASSIC, EXPANDED
}
