package AccountModels;

public enum AccountType {
    // Basic
    ACCOUNT,
    PERSONAL, STUDENT, VIP
}
